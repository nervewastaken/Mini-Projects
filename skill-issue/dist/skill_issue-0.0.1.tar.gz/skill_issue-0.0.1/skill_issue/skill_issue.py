# skill_issue/skill_issue.py

def print_with_user(str):
    print(str + " just had a skill issue")

def skillissue():
    print("skill issue")

def niw():
    print("Nah, I'd win")
