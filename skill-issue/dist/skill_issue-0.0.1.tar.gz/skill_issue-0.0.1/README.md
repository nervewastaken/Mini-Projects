# Skill Issue

This is a simple example package named skill-issue.

## Functions

- `print_with_user(str)`: Prints the string with "just had a skill issue" appended.
- `skillissue()`: Prints "skill issue".
- `niw()`: Prints "Nah, I'd win".
